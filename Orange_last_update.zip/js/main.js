$(document).ready(function(){
	
	   $('.project_list').mixItUp({
	animation: {
		effects: 'rotateX'
	}
  }); 
	  
	  
	  
	  
	  
	  
});
